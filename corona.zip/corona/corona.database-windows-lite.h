#pragma once

#define _WIN32_WINNT _WIN32_WINNT_WIN10 
#define NTDDI_VERSION NTDDI_WIN10_19H1 

#include "windows.h"
#include "windowsx.h"

#include <iostream>




